#!/usr/bin/env python3


for num_colors in range(1,8):
		print('---------------------------------------------------------------------------')
		print(f'num_colors = {num_colors}')
		print('---------------------------------------------------------------------------')
		codes = {}
		temp = False 
		out_codes = []
		num_num = 0
		for a in range(num_colors+1):
			for b in range(num_colors+1):
				for c in range(num_colors+1):
					for d in range(num_colors+1):
						if (a,b,c,d) in codes: continue 
						# 	original - only allow transparency coming in from 1 side.. 
						#	elif a == 0:
						#		if d == 0: 
						#			if c == 0:
						#				if b != 0: continue 
						#			else : continue 
						#		elif c == 0:
						#			if b != 0: continue 
						#	elif d == 0:
						#		if b == 0:
						#			if c != 0: continue 
						#	elif b == 0 or c == 0 : continue
		
						#either side can be transparent but not just middle.
						#if b == 0:
						#	if c == 0:
						#		if a !=0 and d != 0: continue 
						#	elif a != 0: continue 
						#elif c == 0 and d != 0 : continue 
		
						# ok what if transparency per 4 px ..?
						#if a == 0 :
						#	if b != 0 : continue 
						#elif b == 0 : continue 
						#if c == 0 :
						#	if d != 0 : continue 
						#elif 	d == 0 : continue
		
						#just can't be code we've seen
						codes[(a,b,c,d)]=num_num
						codes[(d,c,b,a)]=num_num
						if temp:
							print(f'{a} {b} {c} {d}\t  {d} {c} {b} {a} ')
							out_codes.append(temp+[(a,b,c,d),(d,c,b,a)])
							temp = False
							num_num += 1 
						else:
							temp = [(a,b,c,d),(d,c,b,a)]
							print(f'{num_num}\t: {a} {b} {c} {d}\t  {d} {c} {b} {a}\t|\t',end='')
		print('')
