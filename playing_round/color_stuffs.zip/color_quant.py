def make_hsv_from_rgb(r_,g_,b_):
	r = r_/15
	g = g_/15
	b = b_/15
	Cmax = max(r,g,b)
	Cmin = min(r,g,b)
	delta = Cmax - Cmin

	if delta == 0:
		h = 0
	elif Cmax == r :
		h = 60*( ((g-b)/delta) % 6 ) 
	elif Cmax == g :
		h = 60*( ((b-r)/delta) + 2 )
	else :
		h = 60*( ((r-g)/delta) + 4 )

	if Cmax > 0 : s = delta/Cmax
	else : s = 0

	v = Cmax 

	return h,s,v 


def hue_difference(h_a,h_b):
	max = max(h_a,h_b)
	min = min(h_a,h_b)
	return min(max - min, min + 360 - max )

def sort_key_by_vhs(x):
	h,s,v = x
	return v,h,s # when comparing colors - want colors same value, close in hue, with saturation as tie breaker..


def diff_hsv(hsv_a, hsv_b)
	ha,sa,va = hsv_a
	hb,sb,vb = hsv_b
	return hue_difference(ha,hb), max(sa - sb, sb - sa ), max(va - vb, vb - vb)

 	#sort by diff_hsv? like want close in hue, then saturation match, then value ?  maybe combine to be distance.. ? 

def calc_hsv_distance(hsv_a,hsv_b)
	h,s,v = diff_hsv(hsv_a,hsv_b)
	return (h/360)**2 + s**2 + v**2 	# there's the distance between? 

def dithered_distance_tween(diff):
	h,s,v = diff
	return (h/720)**2 + (s/2)**2 + (v/2)**2 	# there's the distance between? 

"""
would want to limit overall distance for considering dithers? possibly getting more agressive until reduced.
for considering if its a good dither, should consider hue difference / saturation - looking for lower.. so low hue diff
or high saturation diff matters..
"""

def dither_pair_distance(hsv_a,hsv_b):
	h,s,v = diff_hsv(hsv_a,hsv_b)
	if s > 0 :
		return v*h/s
	else : 
		return v*h*1000

"""
so we can start reduction by considering distance to dither pair OR a color.. technically a color could be paired
with itself  - would be dither_pair 

so to get the set of colors down to whatever level, would do passes to identify clusters / chains of colors
so that all the colors inbetween can be lumped into the dither covering the range. 

so methodology - 
"""

def generate_dither_pair_list(palette):
	dither_diffs = []
	i = len(palette)
	while i:
	 	i -= 1
		hsv_a = palette[i][1]
		for j in range(i):
			dither_diffs.append((dither_pair_distance(hsv_a,palette[j][1]),j,i))
	return 	sorted(dither_diffs)

# colors_list is like [( r,g,b), ... ] and doesn't include transparency.. 

def quantize_down_to_palette(colors_list,max_colors):
	replace_list = {}
	num_colors_list = len(colors_list)

	new_color_list = [ (x,make_hsv_from_rgb(x)) for x in colors_list ]
	for rgb in colors_list:
		replace_list[rgb] = rgb

	while len(new_color_list) > max_colors:
		dither_diffs = generate_dither_pair_list(new_color_list)
		low_diff_threshold = dither_diffs[0][0] + 0.0001
		next_color_list = []

		seen = set()
		for dith_dist,j,i in dither_diffs:
			if dith_dist > low_diff_threshold: 
				break
			seen.add(i)
			seen.add(j) 
			Ar,Ag,Ab = entryA = new_color_list[0]
			Br,Bg,Bb = entryB = new_color_list[0]
			new_color_RGB = (int((Ar+Br/2)),int((Ag+Bg)/2),int((Ab+Bb)/2)) #smoosh
			new_color_HSV = make_hsv_from_rgb(new_color_RGB)
			replace_list[entryA] = new_color_RGB 
			replace_list[entryB] = new_color_RGB
			next_color_list.append((new_color_RGB,new_color_HSV))

		for index in sorted(list(seen),reverse=True):
			new_color_list.pop(index)

		new_color_list += next_color_list
	final_replace_list = {}
	for RGB in colors_list:
		lookup = RGB
		while True :
			replace_with = replace_list[lookup]
			if lookup == replace_with :
				break
			lookup = replace_with
		final_replace_list[RGB] = lookup

	return 	new_color_list,final_replace_list

"""
 yeah, that should work.. find the distance between like for a dither and merge colors at midpoint? 
 but also was idea could use dithers to replace colors... 
 well... maybe with further thresholding? 
"""
def quantize_dither_palette(colors_list,max_colors,dither_threshold):
	replace_list = {}
	num_colors_list = len(colors_list)

	new_color_list = [ (x,make_hsv_from_rgb(x)) for x in colors_list ]
	for rgb in colors_list:
		replace_list[rgb] = rgb
	replace_with_dither = {}

	while len(new_color_list) > max_colors:
		dither_diffs = generate_dither_pair_list(new_color_list)
		low_diff_threshold = dither_diffs[0][0] + 0.0001
		next_color_list = []

		seen = set()
		dither_ends = set()
		needs_removed = len(new_color_list) - max_colors

		print(f'low_diff_threshold : {low_diff_threshold}')

		for dith_dist,j,i in dither_diffs:
			Ar,Ag,Ab = entryA[0] = new_color_list[i]
			Br,Bg,Bb = entryB[0] = new_color_list[j]
			if dith_dist < low_diff_threshold: 
				seen.add(i)
				seen.add(j) 
				new_color_RGB = (int((Ar+Br/2)),int((Ag+Bg)/2),int((Ab+Bb)/2)) #smoosh
				new_color_HSV = make_hsv_from_rgb(new_color_RGB)
				replace_list[entryA] = new_color_RGB 
				replace_list[entryB] = new_color_RGB
				next_color_list.append((new_color_RGB,new_color_HSV))
				needs_removed -= 1 
				if not needs_removed : break 
			elif dith_dist > dither_threshold:
				break
			else :	# let's consider these as dither endpoints and try to find colors in between.. 
				dith_dist_threshold =  dith_dist * 1.1 
				print(f'dith_dist_threshold : {dith_dist_threshold}')
				for dith_dist2,l,k in dither_diffs:
					if dith_dist2 < low_diff_threshold :
						continue 
					elif dith_dist2 < dith_dist:
						if i == k :
							if dither_pair_distance(new_color_list[j][1],new_color_list[l][1]) + dith_dist2 < dith_dist_threshold:
								seen.add(l)
								replace_with_dither[new_color_list[l][0]] = (entryA,entryB)
								dither_ends.add(i)
								dither_ends.add(j)
								needs_removed -= 1 
								if not needs_removed : break 
						elif i == l :
							if dither_pair_distance(new_color_list[j][1],new_color_list[k][1]) + dith_dist2 < dith_dist_threshold:
								seen.add(k)
								replace_with_dither[new_color_list[k][0]] = (entryA,entryB) .
								dither_ends.add(i)
								dither_ends.add(j)
								needs_removed -= 1 
								if not needs_removed : break 
						elif j == k :
							if dither_pair_distance(new_color_list[i][1],new_color_list[l][1]) + dith_dist2 < dith_dist_threshold:
								seen.add(l)
								replace_with_dither[new_color_list[l][0]] = (entryA,entryB) 
								dither_ends.add(i)
								dither_ends.add(j)
								needs_removed -= 1 
								if not needs_removed : break 
						elif j == l :
							if dither_pair_distance(new_color_list[i][1],new_color_list[k][1]) + dith_dist2 < dith_dist_threshold:
								seen.add(k)
								replace_with_dither[new_color_list[k][0]] = (entryA,entryB) 
								dither_ends.add(i)
								dither_ends.add(j)
								needs_removed -= 1 
								if not needs_removed : break 
					else : 
						break
			print(f'needs_removed : {needs_removed} | {dith_dist} | {j} | {i} || next_color_list size : {len(next_color_list)}')

		for index in sorted(list(seen.difference(dither_ends)),reverse=True): 	# ensures our dither endpoints continue to exist.. for now
			new_color_list.pop(index)
			# but also means replacement colors could be added just to end up removed... but since it is merge then dither...
			# should overall end up with same or less colors each iteration.. 
		new_color_list += next_color_list

	return 	new_color_list,replace_list,replace_with_dither 	# probably messy.. could have disappeared dither endpoints.. 
