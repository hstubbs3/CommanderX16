#/usr/bin/env python3

codes = {}
temp = False 
out_codes = []
num_num = 0 
for a in range(8):
	for b in range(8):
		for c in range(8):
			for d in range(8):
				if (a,b,c,d) in codes: continue 
				elif a == 0:
					if d == 0: 
						if c == 0:
							if b != 0: continue 
						else : continue 
					elif c == 0:
						if b != 0: continue 
				elif d == 0:
					if b == 0:
						if c != 0: continue 
				elif b == 0 or c == 0 : continue
				codes[(a,b,c,d)]=num_num
				codes[(d,c,b,a)]=num_num
				if temp:
					print(f'{a} {b} {c} {d}\t  {d} {c} {b} {a} ')
					out_codes.append(temp+[(a,b,c,d),(d,c,b,a)])
					temp = False
					num_num += 1 
				else:
					temp = [(a,b,c,d),(d,c,b,a)]
					print(f'{num_num} : {a} {b} {c} {d}\t  {d} {c} {b} {a} | ',end='')
