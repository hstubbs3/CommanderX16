#!/usr/bin/env python3
import sys
import numpy as np
import cv2 as cv
from time import sleep


"""
Different approach to this color reduction mess..

is only 512 colors in the entire pixel space.. so initially reduce to that color space - 9 bit.

Then brute force the color space looking for a first / base color that produces the least error overall. 

Then starting with the second color, for each point, evaluate error considering the palette so far,
considering for each 2x2 / 4x4 / 8x8 section if no dithering or ordered dithering is best and which color to add.

Or maybe just use the blue noise void and whatever dithering ? 

http://momentsingraphics.de/BlueNoise.html

https://bartwronski.com/2016/10/30/dithering-part-three-real-world-2d-quantization-dithering/

02
13

082A
C4E6
3B19
F7D5

InterleavedGradientNoise[x_, y_] :=
FractionalPart[52.9829189*FractionalPart[0.06711056*x + 0.00583715*y]]

"""
def make_hsv_from_rgb(r_,g_,b_):
	r = r_/255
	g = g_/255
	b = b_/255
	Cmax = max(r,g,b)
	Cmin = min(r,g,b)
	delta = Cmax - Cmin

	if delta == 0:
		h = 0
	elif Cmax == r :
		h = 60*( ((g-b)/delta) % 6 ) 
	elif Cmax == g :
		h = 60*( ((b-r)/delta) + 2 )
	else :
		h = 60*( ((r-g)/delta) + 4 )
	if Cmax > 0 : s = delta/Cmax
	else : s = 0
	v = Cmax 
	return h,s,v 

def make_rgb_from_hsv(h,s,v):
	c = v * s 
	x = c * ( 1 - abs( ((h/60) % 2) -1 ) )
	m = v - c 
	if h < 60 : 	r,g,b = (c,x,0)
	elif h <120 : 	r,g,b = (x,c,0)
	elif h < 180 : 	r,g,b = (0,c,x)
	elif h < 240 : 	r,g,b = (0,x,c)
	elif h < 300 :	r,g,b = (x,0,c)
	else :			r,g,b = (c,0,x)
	return int((r+m)*255),int((g+m)*255),int((b+m)*255)

img = cv.imread("nature.png", cv.IMREAD_ANYCOLOR)
original_width = len(img[0])
original_height = len(img)

cv.imshow("original", img)
cv.moveWindow("original",0,-1080)

width = 120
height = 84
#resized = np.zeros((height,width,3),np.uint8)
resized_sampled = np.zeros((height,width,3),np.uint8)

scale = max(original_height / height , 0.8*original_width/width )

print(f'scale : {scale}')
resized_width = int(0.8*original_width/scale)
print(f'resized width is {resized_width} of {width}')
resized_height= int(original_height/scale)
print(f'resized height is {resized_height} of {height}')
img_out_scaled = np.zeros((448,640,3),np.uint8)
for y in range(32,64):
	for x in range(640):
		img_out_scaled[y][x] = [ 128, 128, 128 ]
for y in range(400,432):
	for x in range(640):
		img_out_scaled[y][x] = [ 128, 128, 128 ]

def scale_up_display(img,windowName):
	global img_out_scaled
	y_offset = 64 + int(84 - resized_height)*2
	x_offset_start = int(160 - 1.25*resized_width)*2 
	print(f'x_offset_start = {x_offset_start}')
	for y,row in enumerate(img):
		if y >= resized_height : break
		x_offset = x_offset_start
		for x,pixel in enumerate(row):
			if x >= resized_width : break 
			for j in range(4):
				for i in range(5):
					try:
						img_out_scaled[y_offset+j][x_offset+i]=pixel
					except Exception as e:
						print(f'y_offset+j = {y_offset+j} x_offset+i = {x_offset+i} '+'\t'.join([str(_) for _ in ['\t',y_offset,j,x_offset,i]]))
						raise
			x_offset += 5
		y_offset += 4
	cv.imshow(windowName,img_out_scaled)


def scale_up_display_chunky_wavy(img,windowName):
	global img_out_scaled
	y_offset = 64 + int(84 - resized_height)*2
	x_offset_start = int(160 - 1.25*resized_width)*2 
	for y,row in enumerate(img):
		if y >= resized_height : break
		x_offset = x_offset_start
		x = 0 
		for a,b,c,d in zip(row[::4],row[1::4],row[2::4],row[3::4]):
				#print(f'y {y} x {x} x_offset {x_offset} y_offset {y_offset} ')
				if x_offset >= 640 : break
				img_out_scaled[y_offset+0][x_offset+0]=a
				img_out_scaled[y_offset+1][x_offset+0]=a
				img_out_scaled[y_offset+0][x_offset+1]=a
				img_out_scaled[y_offset+1][x_offset+1]=a


				img_out_scaled[y_offset+0][x_offset+2]=a
				img_out_scaled[y_offset+1][x_offset+2]=a
				img_out_scaled[y_offset+0][x_offset+3]=a
				img_out_scaled[y_offset+1][x_offset+3]=a
				img_out_scaled[y_offset+0][x_offset+4]=a
				img_out_scaled[y_offset+1][x_offset+4]=a


				img_out_scaled[y_offset+0][x_offset+5]=b
				img_out_scaled[y_offset+1][x_offset+5]=b
				img_out_scaled[y_offset+0][x_offset+6]=b
				img_out_scaled[y_offset+1][x_offset+6]=b

				img_out_scaled[y_offset+0][x_offset+7]=b
				img_out_scaled[y_offset+1][x_offset+7]=b
				img_out_scaled[y_offset+0][x_offset+8]=b
				img_out_scaled[y_offset+1][x_offset+8]=b
				img_out_scaled[y_offset+0][x_offset+9]=b
				img_out_scaled[y_offset+1][x_offset+9]=b

				img_out_scaled[y_offset+0][x_offset+10]=c
				img_out_scaled[y_offset+1][x_offset+10]=c
				img_out_scaled[y_offset+0][x_offset+11]=c
				img_out_scaled[y_offset+1][x_offset+11]=c

				img_out_scaled[y_offset+0][x_offset+12]=d
				img_out_scaled[y_offset+1][x_offset+12]=d
				img_out_scaled[y_offset+0][x_offset+13]=d
				img_out_scaled[y_offset+1][x_offset+13]=d
				img_out_scaled[y_offset+0][x_offset+14]=d
				img_out_scaled[y_offset+1][x_offset+14]=d

				img_out_scaled[y_offset+0][x_offset+15]=c
				img_out_scaled[y_offset+1][x_offset+15]=c
				img_out_scaled[y_offset+0][x_offset+16]=c
				img_out_scaled[y_offset+1][x_offset+16]=c

				img_out_scaled[y_offset+0][x_offset+17]=d
				img_out_scaled[y_offset+1][x_offset+17]=d
				img_out_scaled[y_offset+0][x_offset+18]=d
				img_out_scaled[y_offset+1][x_offset+18]=d
				img_out_scaled[y_offset+0][x_offset+19]=d
				img_out_scaled[y_offset+1][x_offset+19]=d




				img_out_scaled[y_offset+2][x_offset+0]=a
				img_out_scaled[y_offset+3][x_offset+0]=a
				img_out_scaled[y_offset+2][x_offset+1]=a
				img_out_scaled[y_offset+3][x_offset+1]=a


				img_out_scaled[y_offset+2][x_offset+2]=b
				img_out_scaled[y_offset+3][x_offset+2]=b
				img_out_scaled[y_offset+2][x_offset+3]=b
				img_out_scaled[y_offset+3][x_offset+3]=b
				img_out_scaled[y_offset+2][x_offset+4]=b
				img_out_scaled[y_offset+3][x_offset+4]=b


				img_out_scaled[y_offset+2][x_offset+5]=a
				img_out_scaled[y_offset+3][x_offset+5]=a
				img_out_scaled[y_offset+2][x_offset+6]=a
				img_out_scaled[y_offset+3][x_offset+6]=a

				img_out_scaled[y_offset+2][x_offset+7]=b
				img_out_scaled[y_offset+3][x_offset+7]=b
				img_out_scaled[y_offset+2][x_offset+8]=b
				img_out_scaled[y_offset+3][x_offset+8]=b
				img_out_scaled[y_offset+2][x_offset+9]=b
				img_out_scaled[y_offset+3][x_offset+9]=b

				img_out_scaled[y_offset+2][x_offset+10]=c
				img_out_scaled[y_offset+3][x_offset+10]=c
				img_out_scaled[y_offset+2][x_offset+11]=c
				img_out_scaled[y_offset+3][x_offset+11]=c

				img_out_scaled[y_offset+2][x_offset+12]=c
				img_out_scaled[y_offset+3][x_offset+12]=c
				img_out_scaled[y_offset+2][x_offset+13]=c
				img_out_scaled[y_offset+3][x_offset+13]=c
				img_out_scaled[y_offset+2][x_offset+14]=c
				img_out_scaled[y_offset+3][x_offset+14]=c

				img_out_scaled[y_offset+2][x_offset+15]=d
				img_out_scaled[y_offset+3][x_offset+15]=d
				img_out_scaled[y_offset+2][x_offset+16]=d
				img_out_scaled[y_offset+3][x_offset+16]=d

				img_out_scaled[y_offset+2][x_offset+17]=d
				img_out_scaled[y_offset+3][x_offset+17]=d
				img_out_scaled[y_offset+2][x_offset+18]=d
				img_out_scaled[y_offset+3][x_offset+18]=d
				img_out_scaled[y_offset+2][x_offset+19]=d
				img_out_scaled[y_offset+3][x_offset+19]=d
				x+=4
				x_offset+=20
		y_offset += 4
	cv.imshow(windowName,img_out_scaled)

for o_y,r_y in [ (int(y*scale),y) for y in range(height) if int(y*scale) < original_height]:
	for o_x,r_x in [ (int(x*scale*1.25),x) for x in range(width) if int(x*scale*1.25) < original_width]:
		"""
		try:
			resized[r_y][r_x] = img[o_y][o_x]
		except Exception as e:
			print(f'o_x : {o_x} o_y : {o_y} r_x : {r_x} r_y : {r_y}')
			raise
		"""
		try:
			accumulator = [ 0, 0, 0]
			for i in range(int(1.25*scale)):
				if o_x+i >= original_width: break
				for j in range(int(scale)):
					if o_y+j >= original_height : break
					accumulator[0] += img[o_y+j][o_x+i][0]
					accumulator[1] += img[o_y+j][o_x+i][1]
					accumulator[2] += img[o_y+j][o_x+i][2]
			resized_sampled[r_y][r_x] = [ int(acc/(int(1.25*scale)*int(scale) ) ) for acc in accumulator ]
		except Exception as e:
			print(f'o_x : {o_x} o_y : {o_y} r_x : {r_x} r_y : {r_y}')
			raise
scale_up_display(resized_sampled,"averaged")
cv.moveWindow("averaged",original_width,-1080)
"""
cv.imshow("resized",resized)
cv.moveWindow("resized",0,-1080)
scale_up_display(resized,"nearNeighbor")
cv.moveWindow("nearNeighbor",original_width,-1080)


blend = np.zeros((height,width,3),np.uint8)

for y in range(height):
	for x in range(width):
		pixelA = resized[y][x]
		pixelB = resized_sampled[y][x]
		print(f'y {y} x {x} {pixelA} {pixelB}')
		blend[y][x] = [ int( (pixelA[0] + pixelB[0]) / 2), int( (pixelA[1] + pixelB[1]) / 2), int( (pixelA[2] + pixelB[2]) / 2) ]
scale_up_display(blend,"blended")
cv.moveWindow("blended",original_width+640,512-1080)
"""
img_9bit = np.zeros((height,width,3),np.uint8)
img_9bit_error = np.zeros((height,width,3),np.uint8)

for y,row in enumerate(resized_sampled):
	for x,pixel in enumerate(row) :
		for i,chan in enumerate(pixel) :
			error = chan % 32 
			img_9bit[y][x][i] = chan - error
			img_9bit_error[y][x][i] = error * 8


img_9bit_floyd = np.zeros((height,width,3),np.uint8)
img_9bit_min_avg_error = np.zeros((height,width,3),np.uint8)

img_9bit_ordered_dither =  np.zeros((height,width,3),np.uint8)

floyd_steinberg_kernel = [ 	[ 0, 0, 7], 	# 1/16
							[ 3, 5, 1] ] 
minimized_average_error_kernel = 	[ 	[ 0, 0, 0, 7, 5], # 1/48
										[ 3, 5, 7, 5, 3],
										[ 1, 3, 5, 3, 1]]
ordered_dither_bayer_kernel = [ 	[  0,  8,  2, 10 ],
									[ 12,  4, 14,  6 ],
									[  3, 11,  1,  9 ],
									[ 15,  7, 13,  5 ]]

for y in range(height):
	if not y % 8:
		print('.',end="")
	for x in range(width):
		error = [resized_sampled[y][x][i] - img_9bit[y][x][i] for i in range(3)]
		#floyd and steinberg
		floyd_error = [error[i] + img_9bit_floyd[y][x][i] for i in range(3)]
		curr_error = [int(e/32)*32 for e in floyd_error]
		img_9bit_floyd[y][x] = [min(255,img_9bit[y][x][i] + curr_error[i]) for i in range(3)]
		floyd_error = [ floyd_error[i] - curr_error[i] for i in range(3)]
		for j,row in enumerate(floyd_steinberg_kernel):
			if y + j >= height : break 
			for i,value in enumerate(row,-1):
				if x + i < 0 : continue
				if x + i >= width : break
				if j == 0 and i < 1 : continue
				img_9bit_floyd[y+j][x+i] = [img_9bit_floyd[y+j][x+i][z] + int(value * floyd_error[z] / 16) for z in range(3)]

		min_avg_error = [error[i] + img_9bit_min_avg_error[y][x][i] for i in range(3)]
		curr_error = [int(e/32)*32 for e in min_avg_error]
		img_9bit_min_avg_error[y][x] = [min(255,img_9bit[y][x][i] + curr_error[i]) for i in range(3)]
		min_avg_error = [ min_avg_error[i] - curr_error[i] for i in range(3)]
		for j,row in enumerate(minimized_average_error_kernel):
			if y + j >= height : break 
			for i,value in enumerate(row,-2):
				if j == 0 and i < 1: continue
				if x + i < 0 : continue
				if x + i >= width : break 
				img_9bit_min_avg_error[y+j][x+i] = [img_9bit_min_avg_error[y+j][x+i][z] + int(value * min_avg_error[z] / 48 ) for z in range(3)]
		factor = ordered_dither_bayer_kernel[y % 4][x % 4]
		img_9bit_ordered_dither[y][x] = [ min(255,attempt - (attempt % 32 ) ) for attempt in [int(original + 31 - factor)  for original in resized_sampled[y][x] ] ]

print('')

cv.imshow("9 bit", img_9bit)
cv.moveWindow("9 bit",original_width+width,-1080)
scale_up_display(img_9bit,"9 bit scaled")
cv.moveWindow("9 bit scaled",original_width+640,-1080)

cv.imshow("9 bit error", img_9bit_error)
cv.moveWindow("9 bit error",original_width + 2 * width,-1080)
cv.imshow("img_9bit_floyd",img_9bit_floyd)
cv.moveWindow("img_9bit_floyd",0,height-1080)
cv.imshow("img_9bit_min_avg_error",img_9bit_min_avg_error)
cv.moveWindow("img_9bit_min_avg_error",width,height-1080)
cv.imshow("img_9bit_ordered_dither", img_9bit_ordered_dither)
cv.moveWindow("img_9bit_ordered_dither",width*2,height-1080)

scale_up_display(img_9bit_floyd,"img_9bit_floyd scaled")
cv.moveWindow("img_9bit_floyd scaled",0,original_height-1080)
scale_up_display(img_9bit_min_avg_error,"img_9bit_min_avg_error scaled")
cv.moveWindow("img_9bit_min_avg_error scaled",640,original_height-1080)
scale_up_display(img_9bit_ordered_dither,"img_9bit_ordered_dither scaled")
cv.moveWindow("img_9bit_ordered_dither scaled",1280,original_height-1080)

scale_up_display_chunky_wavy(img_9bit_ordered_dither,"img_9bit_ordered_dither wavy")

quantized_8color_chunky_bg_tester = np.zeros((height,width,3),np.uint8)
def diff_hsv(h,s,v,hh,ss,vv):
	if h > hh :
		dh = min(h - hh, hh + 360 - h)
	else :
		dh = min(hh -h, h + 360 - hh)
	ds = max(s - ss, ss - s )
	dv = max(v - vv, vv - v )
	return dh/360 + (ds*0.5) + (dv * 1.1)


color_nums = {}
for i,r in enumerate(range(0,255,32)):
	for j,g in enumerate(range(0,255,32)):
		for k,b in enumerate(range(0,255,32)):
			color_nums[(r,g,b)] = i*64 + j * 8 + k 

def make_color_palette(img,num_colors,width,height,max_passes=False):
		global color_nums

		if not max_passes:
			max_passes = num_colors #/ 2
		colors = set()
		cache = [[[ -1 for _ in range (width)] for _ in range(height) ] for _ in range(512)]

		weirding_factor = width*height
		weirding_error = weirding_factor
		passes = -1 
		colors = {}
		while passes < max_passes:
			if passes == 0 :
				colors = {}
			passes +=1
			if colors :
				replace = False
				check_error = 0
				for color,data in colors.items():
					if not replace or data['error'] < check_error:
							replace = color
							check_error = data['error']
				del colors[replace]

			while len(colors) < num_colors :
				do_color = len(colors)
				print(f'pass {passes} / {max_passes}  - checking for color {do_color}')
				low_error = 0
				best_color = (0,0,0)
				best_error_pixels = 0
				for r in range(0,255,32):
					for g in range(0,255,32):
						for b in range(0,255,32):
							if (r,g,b) in colors : 
								print(f'skipping {r} , {g} , {b} - already in palette')
								continue
							color_num_lookup = color_nums[(r,g,b)]
							h,s,v = make_hsv_from_rgb(r,g,b)
							error_pixels = 0 
							covered_pixels = 0
							#print(f'\t{len(colors)} : checking {r} , {g} ,  {b}',end="")
							error = 0
							for y,row in enumerate(resized_sampled) :
								for x,pixel in enumerate(row) :
			
									pixel_error = cache[color_num_lookup][y][x]
									#print(f'{do_color} - ( {r} {g} {b} ) lookup {color_num_lookup} for pixel {x} {y} - error {pixel_error}')
									if pixel_error < 0 :
										#print(f'cache failed boss.. {do_color} - ( {r} {g} {b} ) lookup {color_num_lookup} for pixel {x} {y}')
										rr,gg,bb = pixel
										hh,ss,vv = make_hsv_from_rgb(rr,gg,bb)
										pixel_error =  diff_hsv(h,s,v,hh,ss,vv)
										#print(pixel,rr,gg,bb,pixel_error)
										cache[color_num_lookup][y][x]=pixel_error
									#else :
									#	print(f'{do_color} - ( {r} {g} {b} ) lookup {color_num_lookup} for pixel {x} {y} - error {pixel_error}')
									if pixel_error > weirding_error / num_colors :
										error += pixel_error
									else :
										error_pixels += 1
										#print('.',end="")
									weirding_error = ((weirding_factor - 1) * weirding_error + pixel_error) / weirding_factor
							#print(f'{do_color} - ( {r} {g} {b} ) lookup {color_num_lookup} \t error pixels = {error_pixels} total error: {error}')
							if error > 0 :
								error = error_pixels / error  

							if error > low_error  :
								print(f'{passes} : : {r} {g} {b} new best for #{len(colors)} - error pixels = {error_pixels} - total error {error} ! - weirding : {weirding_error}')
								low_error = error 
								best_color = (r,g,b)
								best_error_pixels = error_pixels
				if len(colors) < num_colors :
					colors[best_color] = { 'error':low_error, 'error_pixels':best_error_pixels }
				else :
					replace = False
					check_error = 0
					for color,data in colors.items():
						if data['error'] > low_error :
							if not replace or data['error'] > check_error:
								replace = color
								check_error = data['error']
					if replace :
						del colors[replace]
						colors[best_color] = { 'error':low_error, 'error_pixels':best_error_pixels }
				print(f'pass {passes} - bottom of best_color check')
				for color in colors :
					print(f'{color} - {colors[color]}')
		return colors,cache

#colors,cache = make_color_palette(resized_sampled,8 ,width,height)

def make_optimized_simple_palette(img,num_colors):
		colors = {}
		for row in img :
			for r,g,b in row :
				r -= r%32
				g -= g%32
				b -= b%32
				color = (r,g,b)
				if color in colors :
					colors[color] += 1 
				else:
					colors[color] = 1
		last_min_contrast = 0 
		while len(colors) > num_colors :
			min_contrast = 512
			colors_list = sorted(colors.items(),key=lambda x: x[1])
			replace_this = False 
			replaced_by = False 
			for i,color_data, in enumerate(colors_list):
				r,g,b = color = color_data[0]
				num_pixels = color_data[1]
				v = max(r,g,b)
				s = v - min(r,g,b)
				for j in range(i+1,len(colors_list)):
					check_color = colors_list[j][0]
					rr,gg,bb = check_color
					vv = max(r,g,b)
					ss = vv - min(r,g,b)
					dd = (r-rr)**2 + (g-gg)**2 + (b-bb)**2 
					dv = abs(vv - v)
					ds = abs(ss - s)
					# minimum these could be apart in any one thing is 32.. so +/- one spot across = 3072
					if dd < 4096 and dv <= min_contrast and ds <=32: # sure, these appear maybe pretty close.. 
						replace_this = color 
						min_contrast = dv 
						replaced_by = check_color
						print(f'{len(colors)} / {num_colors} : {i} : bit too close to {j} buddy... {dv} ::  {color} -> {check_color}')
			if replace_this :
				colors[replaced_by] += colors[replace_this]
				del colors[replace_this]
			else :
				print(f'nothing to replace boss... gotta die here.. ')
				break

		return colors


colors = make_optimized_simple_palette(resized_sampled,8)

for r,g,b in colors :
	print(f'{r} {g} {b}')

quantized_8color_chunky_bg_tester = np.zeros((height,width,3),np.uint8)
for y,row in enumerate(resized_sampled):
	for x,pixel in enumerate(row):
		rr,gg,bb = pixel
		color = False 
		low_distance = 256**4
		for r,g,b in colors :
			dd = (r-rr)**2 + (g-gg)**2 + (b-bb)**2 
			if dd < low_distance :
				color = [r,g,b]
				low_distance = dd 
		quantized_8color_chunky_bg_tester[y][x] = color
scale_up_display_chunky_wavy(quantized_8color_chunky_bg_tester,"8 color BG test")
cv.moveWindow("8 color BG test",640,height-1080)

colors = make_optimized_simple_palette(img_9bit_ordered_dither,16)

quantized_8color_chunky_bg_tester = np.zeros((height,width,3),np.uint8)
for y,row in enumerate(img_9bit_ordered_dither):
	for x,pixel in enumerate(row):
		rr,gg,bb = pixel
		color = False 
		low_distance = 256**4
		for r,g,b in colors :
			dd = (r-rr)**2 + (g-gg)**2 + (b-bb)**2 
			if dd < low_distance :
				color = [r,g,b]
				low_distance = dd 
		quantized_8color_chunky_bg_tester[y][x] = color
scale_up_display_chunky_wavy(quantized_8color_chunky_bg_tester,"16 color BG test - ordered_dither_source")
cv.moveWindow("8 color BG test - ordered_dither_source",1280,height-1080)





img_9bit_double_ordered_dither =  np.zeros((height,width,3),np.uint8)
for y in range(height):
	if not y % 8:
		print('.',end="")
	for x in range(width):
		factor = ordered_dither_bayer_kernel[y % 4][x % 4]
		img_9bit_double_ordered_dither[y][x] = [ min(255,attempt - (attempt % 32 ) ) for attempt in [int(original + 31 - factor)  for original in resized_sampled[y][x] ] ]


colors = make_optimized_simple_palette(img_9bit_double_ordered_dither,16)

quantized_8color_chunky_bg_tester2 = np.zeros((height,width,3),np.uint8)
for y,row in enumerate(img_9bit_double_ordered_dither):
	for x,pixel in enumerate(row):
		rr,gg,bb = pixel
		color = False 
		low_distance = 256**4
		for r,g,b in colors :
			dd = (r-rr)**2 + (g-gg)**2 + (b-bb)**2 
			if dd < low_distance :
				color = [r,g,b]
				low_distance = dd 
		quantized_8color_chunky_bg_tester2[y][x] = color

scale_up_display_chunky_wavy(quantized_8color_chunky_bg_tester2,"double dithered before 16 color")
cv.moveWindow("double dithered before 16 color",1280,height-1080)

img_9bit_variable_dither = np.zeros((height,width,3),np.uint8)
for y in range(height):
	if not y % 8:
		print('.',end="")
	for x in range(width):
		factor = ordered_dither_bayer_kernel[y % 4][x % 4]
		img_9bit_variable_dither[y][x] = [ min(255,attempt - (attempt % 16 ) ) for attempt in [int(original + 15 - factor/2)  for original in img_9bit_ordered_dither[y][x] ] ]

colors = make_optimized_simple_palette(img_9bit_variable_dither,16)

quantized_8color_chunky_bg_tester3 = np.zeros((height,width,3),np.uint8)
for y,row in enumerate(img_9bit_variable_dither):
	for x,pixel in enumerate(row):
		rr,gg,bb = pixel
		color = False 
		low_distance = 256**4
		for r,g,b in colors :
			dd = (r-rr)**2 + (g-gg)**2 + (b-bb)**2 
			if dd < low_distance :
				color = [r,g,b]
				low_distance = dd 
		quantized_8color_chunky_bg_tester3[y][x] = color

scale_up_display_chunky_wavy(quantized_8color_chunky_bg_tester3,"img_9bit_variable_dither")
cv.moveWindow("img_9bit_variable_dither",1280,height-1080)


def make_fancy_dither_9bit_palette(img,num_colors):
		colors = {}
		for row in img :
			for r,g,b in row :
				r -= r%32
				g -= g%32
				b -= b%32
				color = (r,g,b)
				if color in colors :
					colors[color] += 1 
				else:
					colors[color] = 1
		sorted_color_list = [ color for color in colors ].sort(key = lambda x: colors[x],reverse = True)
		# oops.. clear up lack of contrast here... 
		while len(colors) > num_colors :
			for row in img:
				for c in row :
					p_r,p_g,p_b = c
					sorted_color_list = [ color for color in colors ].sort(key = lambda x: colors[x],reverse = True)
					low_distanceA = 1638400
					low_distanceB = 1638400
					sat_diff_A = 256
					sat_diff_B = 256
					v_diff_A = 256
					v_diff_B = 256
					dither_A = False
					dither_B = False 

					while sorted_color_list :
						r,g,b = scapegoat_color = sorted_color_list.pop()
						dd =  (r-p_r)**2 + (g-p_g)**2 + (b-p_b)**2 
						if dd > low_distanceA : continue
						low_distanceA = dd 
						sat_diff = abs( max(p_r,p_g,p_b ) - min (p_r,p_g,p_b ) - max(r,g,b) + min(r,g,b))
						if sat_diff > sat_diff_A: continue
						sat_diff_A = sat_diff
						v_diff = abs(max(p_r,p_g,p_b ) - max(r,g,b))
						if v_diff > v_diff_A : continue
						v_diff_A = v_diff
						dither_A = scapegoat_color
						for i,keep_color in enumerate(sorted_color_list) :
							rr,gg,bb = keep_color
							dd  = (p_r-rr)**2 + (p_g-gg)**2 + (p_b-bb)**2 
							if dd > low_distanceB : continue 
							low_distanceB = dd 
							sat_diff = abs( max(p_r,p_g,p_b ) - min (p_r,p_g,p_b ) - max(rr,gg,bb) + min(rr,gg,bb))
							if sat_diff > sat_diff_B: continue
							sat_diff_B = sat_diff
							v_diff = abs(max(p_r,p_g,p_b ) - max(rr,gg,bb))
							if v_diff > v_diff_B : continue 
							dither_B = keep_color
								# hmmm.. that color we popped might not be too bad to keep around... 
					if dither_A or dither_B :
						print(f'OK... upping {dither_A} and {dither_B}')
					if dither_A :
							colors[dither_A]+=1
					if dither_B :
							colors[dither_B]+=1
			victim = sorted([ color for color in colors ], key = lambda x: colors[x],reverse = True).pop()

			print(f'{len(colors)} / {num_colors} - alas fair {victim}, it has come time to end thee')
			del colors[victim]
		return colors

colors = make_fancy_dither_9bit_palette(resized_sampled,16)

for r,g,b in colors :
	print(f'{r} {g} {b}')

img_test_fancy_dither_quantizer = np.zeros((height,width,3),np.uint8)

quantized_8color_chunky_bg_tester4 = np.zeros((height,width,3),np.uint8)
for y,row in enumerate(resized_sampled):
	for x,pixel in enumerate(row):
		rr,gg,bb = pixel
		color = False 
		low_distance = 256**4
		for r,g,b in colors :
			dd = (r-rr)**2 + (g-gg)**2 + (b-bb)**2 
			if dd < low_distance :
				color = [r,g,b]
				low_distance = dd 
		quantized_8color_chunky_bg_tester4[y][x] = color

scale_up_display_chunky_wavy(quantized_8color_chunky_bg_tester4,"fancy dither quantizer thing")
cv.moveWindow("fancy dither quantizer thing",1280,height-1080)


print('fin')
#for y,row in enumerate(resized_sampled):
#	for x,pixel in enumerate(row):
#		best_color = list(colors.keys())[0]
#		low_error = cache[color_nums[best_color]][y][x]
#		for color in colors:
#			if cache[color_nums[color]][y][x] < low_error :
#				best_color = color
#				low_error = cache[color_nums[color]][y][x]
#		quantized_8color_chunky_bg_tester[y][x]=list(best_color)
#print(quantized_8color_chunky_bg_tester)

cv.waitKey(0)
		#cv2.rectangle(img,(y,y),(y,y),(255,255,255),1)
		#imgOut[y][y]=[255,255,255]


cv.destroyAllWindows() # destroy all windows
