#!/usr/bin/env python3
import sys
import numpy as np
import cv2 as cv
from time import sleep

from colormath.color_diff import delta_e_cie2000
from colormath.color_objects import LabColor, sRGBColor
from colormath.color_conversions import convert_color



def scan_image_for_optimal_dither_plan(img,num_colors=256,target_bits_channel=5,target_bits_red=None,target_bits_green=None,target_bits_blue=None):
	if target_bits_red == None :
		target_bits_red = target_bits_channel
	if target_bits_green == None :
		target_bits_green = target_bits_channel
	if target_bits_blue == None :
		target_bits_blue = target_bits_channel
	modulus_red = 2**(8-target_bits_red)
	modulus_green = 2**(8-target_bits_green)
	modulus_blue = 2**(8-target_bits_blue)

	width,height,depth = img.shape

	palette_colors = set()
	dither_plans = {}
	dither_lookups = {}
	#now we will diff all our colors together.. also note the conversions needed for palette back to BGR..?
	BGR_CIELAB_LOOKUP = {}
	cached_cie2000_diffs = []
	img_bgr = np.zeros((width,height,depth),np.uint8)
	variants = []
	for y,row in enumerate(img):
		for pixel in row:
			#print(pixel)
			b,g,r = pixel
			b = int(b)
			g = int(g)
			r = int(r)
			p = (r,g,b)
			dither_lookups[p] = False # initializing with a lack of data. 
			if p in BGR_CIELAB_LOOKUP:
				continue
			else :
				BGR_CIELAB_LOOKUP[p] = convert_color(sRGBColor(r,g,b,True),LabColor)
				# first, we need to bitcrush to posterized levels... 
				b1 = int(b) - b%modulus_blue
				g1 = int(g) - g%modulus_green
				r1 = int(r) - r%modulus_red
				color1 = (b1,g1,r1)
				if color1 in BGR_CIELAB_LOOKUP:
					continue
				else :
					BGR_CIELAB_LOOKUP[color1] = convert_color(sRGBColor(r1,g1,b1,True),LabColor)
					for color2 in palette_colors :
						b2,g2,r2 = color2
						for color3 in palette_colors :
							if color2 == color3 :
								continue
							b3,g3,r3 = color3
							variants += [ [color1,color2,color2,color3],[color1,color3,color3,color2],[color2,color1,color1,color3] ]
		print(f'end of {y} : {len(variants)}')
	print(f'calculated 9bit starting palette of {len(palette_colors)} and we have {len(dither_lookups)} unique pixels original image and {len(variants)} dithers...')
	for centroid,variant in zip((int((a+b+c+d)/4) for a,b,c,d in [zip(a,b,c,d) for a,b,c,d in [ v for v in variants] ] ),variants):
		dither_plans[centroid] = variant

	#these dither plans are by definition optimal, but we don't know if we have all the original colors .. 
	#OK we have an initial palette and we're ready to go? 
	# so for all the dither lookups in p, we have to find an optimal dither plan from this large set.
	used_centroids = set()
	used_colors = {}
	for p in dither_lookups :
		if p in dither_plans :
			dither_lookups[p] = p
		else :
			low_diff = 1000
			for centroid in dither_plans :
				d= delta_e_cie2000(BGR_CIELAB_LOOKUP[centroid],BGR_CIELAB_LOOKUP[p])
				if d < low_diff :
					low_diff = d
					dither_lookups[p] = centroid
		centroid = dither_lookups[p]
		used_centroids.add(centroid)
		for c in dither_plans[centroid]:
			used_colors[c] = 1 + used_colors.get(c,0)
	print(f' currently at {len(used_colors)} being used in {len(used_centroids)} dithers')
	threshold = 0.0
	while len(used_colors) > num_colors:
		threshold += 0.01
		popular_dither = [(0 -used_colors[a]-used_colors[b]-used_colors[c]-used_colors[d],centroid) for centroid,(a,b,c,d) in [(centroid,dither_plans[centroid]) for centroid in used_centroids ]]
		popular_dither.sort() # dithers sorted from most to least popular counting color usage.. 
		used_colors = {}
		used_centroids = {}
		for p,centroid1 in dither_lookups.items():
			low_dist_cutoff = delta_e_cie2000(BGR_CIELAB_LOOKUP[p],BGR_CIELAB_LOOKUP[centroid1])
			for score,centroid2 in popular_dither:
				d = delta_e_cie2000(BGR_CIELAB_LOOKUP[p],BGR_CIELAB_LOOKUP[centroid2])
				if d < threshold :
					dither_lookups[p] = centroid2
		centroid = dither_lookups[p]
		used_centroids.add(centroid)
		for c in dither_plans[centroid]:
			used_colors[c] = 1 + used_colors.get(c,0)
		print(f'bottom of while loop - currently at {len(used_colors)} being used in {len(used_centroids)} dithers - threshold = {threshold}')

	final_dithers = {p: dither_plans[dither_lookups[p]] for p in dither_lookups}

	return used_colors,final_dithers

def do_dithers(img,dithers):
	img_out = np.zeros((len(img),len(img[0]),3),np.uint8)
	for y,row in enumerate(img):
		y_mod2 = 2*(y % 2)
		for x,pixel in enumerate(row):
			b,g,r = pixel 
			b = int(b)
			g = int(g)
			r = int(r)
			p = (b,g,r)
			img_out[y][x] = dithers[p][ymod2 + (x%2)]
	return img_out

img = cv.imread(sys.argv[1],cv.IMREAD_ANYCOLOR)
colors,dithers=scan_image_for_optimal_dither_plan(img)
print(f'got a palette of {len(colors)} colors')
cv.imshow('HFS III',do_dithers(img,dithers))
print('fin')
cv.waitKey(0)
cv.destroyAllWindows() # destroy all windows
