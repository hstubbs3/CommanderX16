#!/usr/bin/env python3
import sys
import numpy as np
#import cv2 as cv
#from time import sleep
from math import sqrt

"""
strategy for optimal dithering strategy .

cluster original colors within 96 error - most likely to use same dithering plan OR rearrangement or partial plan
ensure a mapping where every original RGB value generates at least 1 dithering candidate.
	means each original color should map to a quantized (h,s,v) - so at least would always get 1 candidate.

Also implies could pre-calc the dithering patterns... 
"""



def quantized_hsv_from_bgr(b_,g_,r_):
			b = b_/255 
			g = g_/255 
			r = r_/255
			v = max(b,g,r)
			Cmin = min(b,g,r)
			delta = v - Cmin
			if v > 0 : 
				s = delta/v 
			else : s = 0
			if delta == 0 :
				h = 0
			elif v == r :
					h = int( 16/3*((b-g)/delta ) % 32 )
			elif v == g :
					h = int( 16/3*((b-r)/delta ) + 32/3)
			else :
					h = int( 16/3*((r-g)/delta ) + 64/3)
			s = int(23*s)
			v = int(15*v)

colors_9bit = []
for b_ in [0,32,64,96,128,160,192,224]: 
#for b_ in range(256):
	for g_ in [0,32,64,96,128,160,192,224]: 
	#for g_ in range(256):
		for r_ in [0,32,64,96,128,160,192,224]:
			b = b_/255 
			g = g_/255 
			r = r_/255
			v = max(b,g,r)
			Cmin = min(b,g,r)
			delta = v - Cmin
			if v > 0 : 
				s = delta/v 
			else : s = 0
			if delta == 0 :
				h = 0
			elif v == r :
					h = int( 16/3*((b-g)/delta ) % 32 )
			elif v == g :
					h = int( 16/3*((b-r)/delta ) + 32/3)
			else :
					h = int( 16/3*((r-g)/delta ) + 64/3)
			s = int(23*s)
			v = int(15*v)
			colors_9bit.append((len(colors_9bit),(b_,g_,r_),(h,s,v)))

centroids = {}

def diff_h(h1,h2):
	if h1 < h2:
		return min(h2 - h1, 32 + h1 - h2)
	else :
		return min(h1 - h2, 32 + h2 - h1)

pair_ban_list = set()
pair_ok_list = set()
with open('optimal_dithers.txt','wt') as outFile:
	outFile.write(f'{colors_9bit}\n')
	c=0
	for (A,cA,(ha,sa,va)) in colors_9bit:
		ba,ga,ra = cA
		for (B,cB,(hb,sb,vb)) in colors_9bit[A:]:
			if (A,B) in pair_ban_list : continue
			bb,gb,rb = cB
			if (A,B) not in pair_ok_list :
				if abs(sa-sb) > 7 :
					if min(sa,sb) == 0 : 
						if abs(va-vb) > 4 : 
							pair_ban_list.add((A,B))
							continue 
					elif diff_h(ha,hb) > 4 :
						pair_ban_list.add((A,B)) 
						continue
				elif abs(va-vb) > 8 : 
					pair_ban_list.add((A,B))
					continue
				elif min(sa,sb) > 4 and diff_h(ha,hb) > 4 : 
					pair_ban_list.add((A,B))
					continue
				pair_ok_list.add((A,B))

			for (C,cC,(hc,sc,vc)) in colors_9bit[B:]:
				if (A,C) in pair_ban_list or (B,C) in pair_ban_list : continue
				bc,gc,rc = cC 
				if (A,C) not in pair_ok_list :
					if abs(sa-sc) > 7 :
						if min(sa,sc) == 0 : 
							if abs(va-vc) > 4 : 
								pair_ban_list.add((A,C))
								continue 
						elif diff_h(ha,hc) > 4 : 
							pair_ban_list.add((A,C))
							continue
					elif abs(va-vc) > 8 : 
						pair_ban_list.add((A,C))
						continue
					elif min(sa,sc) > 4 and diff_h(ha,hc) > 4 : 
						pair_ban_list.add((A,C))
						continue
					pair_ok_list.add((A,C))
				if (B,C) not in pair_ok_list:
					if abs(sb-sc) > 7 :
						if min(sb,sc) == 0 : 
							if abs(vb-vc) > 4 : 
								pair_ban_list.add((B,C))
								continue 
						elif diff_h(hb,hc) > 4 : 
							pair_ban_list.add((B,C))
							continue
					elif abs(vb-vc) > 8 : 
						pair_ban_list.add((B,C))
						continue
					elif min(sb,sc) > 4 and diff_h(hb,hc) > 4 : 
						pair_ban_list.add((B,C))
						continue
					pair_ok_list.add((B,C))

				for (D,cD,(hd,sd,vd)) in colors_9bit[C:]:
					if (A,D) in pair_ban_list or (B,D) in pair_ban_list or (C,D) in pair_ban_list : continue 
					bd,gd,rd = cD 
					if (A,D) not in pair_ok_list:
						if abs(sa-sd) > 7 :
							if min(sa,sd) == 0 : 
								if abs(va-vd) > 4 : 
									pair_ban_list.add((A,D))
									continue 
							elif diff_h(ha,hd) > 4 : 
								pair_ban_list.add((A,D))
								continue
						elif abs(va-vd) > 8 : 
							pair_ban_list.add((A,D))
							continue
						elif min(sa,sd) > 4 and diff_h(ha,hd) > 4 : 
							pair_ban_list.add((A,D))
							continue
						pair_ok_list.add((A,D))
					if (B,D) not in pair_ok_list:
						if abs(sb-sd) > 7 :
							if min(sb,sd) == 0 : 
								if abs(vb-vd) > 4 : 
									pair_ban_list.add((B,D))
									continue 
							elif diff_h(hb,hd) > 4 : 
								pair_ban_list.add((B,D))
								continue
						elif abs(vb-vd) > 8 : 
							pair_ban_list.add((B,D))
							continue
						elif min(sb,sd) > 4 and diff_h(hb,hd) > 4 : 
							pair_ban_list.add((B,D))
							continue
						pair_ok_list.add((B,D))
					if (C,D) not in pair_ok_list:
						if abs(sd-sc) > 7 :
							if min(sd,sc) == 0 : 
								if abs(vd-vc) > 4 : 
									pair_ban_list.add((C,D))
									continue 
							elif diff_h(hd,hc) > 4 : 
								pair_ban_list.add((C,D))
								continue
						elif abs(vd-vc) > 8 : 
							pair_ban_list.add((C,D))
							continue
						elif min(sd,sc) > 4 and diff_h(ha,hb) > 4 : 
							pair_ban_list.add((C,D))
							continue
						pair_ok_list.add((C,D))
					c+=1
					ccb = int((cA[0]+cB[0]+cC[0]+cD[0])/4)
					ccg = int((cA[1]+cB[1]+cC[1]+cD[1])/4)
					ccr = int((cA[2]+cB[2]+cC[2]+cD[2])/4)
					centroid = (ccb,ccg,ccr)
					centroids[(cA,cB,cC,cD)]=centroid
					c_str = f'{c} centroid : {A,B,C,D} : {(cA,cB,cC,cD)} : {centroid}\n'
					#print(c_str,end="")
					outFile.write(c_str)
	c=0
	for b_ in range(0,255,16):
		for g_ in range(0,255,16):
			for r_ in range(0,255,16):
				c+=1
				dither_scores = []
				print(f'{c} doing {(b_,g_,r_)}') 
				for (cA,cB,cC,cD) in centroids :
					ccb,ccg,ccr = centroids[(cA,cB,cC,cD)]
					d = sqt((b_-ccb)**2 + (g_-ccg)**2 + (r_-ccr)**2)
					if d > 32 : continue
					dither_scores.append((d,(cA,cB,cC,cD)))
				dither_scores.sort()
				#print(f'{c} bgr {(b_,g_,r_)} : best is {dither_scores[0][1]} :  {dither_scores[0][0]}')
				oufFile.write(f'{(b_,g_,r_)} : {dither_scores} \n')
"""
b_ = int(sys.argv[1])
g_ = int(sys.argv[2])
r_ = int(sys.argv[3])
print(f'OK going to try and find an "optimal" dither of some color... say {(b_,g_,r_)}')

if True : 
			b = b_/255 
			g = g_/255 
			r = r_/255
			v = max(b,g,r)
			Cmin = min(b,g,r)
			delta = v - Cmin
			if v > 0 : 
				s = delta/v 
			else : s = 0
			if delta == 0 :
				h = 0
			elif v == r :
					h = int( 16/3*((b-g)/delta ) % 32 )
			elif v == g :
					h = int( 16/3*((b-r)/delta ) + 32/3)
			else :
					h = int( 16/3*((r-g)/delta ) + 64/3)
			s = int(23*s)
			v = int(15*v)
			print(f'OK got that going as {h} {s} {v}')
			candidates = [(i,b,g,r) for i,(b,g,r) in enumerate(sorted([ p for p,hsv in ( set(h_l[h])  | set(s_l[s]) | set(v_l[v]))]))]
			min_dither_d = max_dither_d = int(sys.argv[4])
			plan = False 
			checks = 0
			while not plan:
				min_dither_d -= 16
				max_dither_d += 16
				low_e = 10000000
				plan = False
				for A,ba,ga,ra in candidates:
					print(f'doing {A} of {len(candidates)} - min_dither_d {min_dither_d}  max_dither_d {max_dither_d}')
					for B,bb,gb,rb in candidates[A:]:
						ab_error = (ba-bb)**2 + (ga-gb)**2 + (ra - rb)**2
						if max_dither_d < ab_error : continue 
						#if min_dither_d > ab_error : continue 
						for C,bc,gc,rc in candidates[B:]:
							ac_error = (ba-bc)**2 + (ga-gc)**2 + (ra - rc)**2
							if max_dither_d < ab_error + ac_error : continue
							#if min_dither_d < ab_error + ac_error : continue
							bc_error = (bb-bc)**2 + (gb-gc)**2 + (rb - rc)**2
							if max_dither_d < ab_error + ac_error + bc_error : continue
							#if min_dither_d > ab_error + ac_error + bc_error : continue
							for D,bd,gd,rd in candidates[C:]:
								ad_error = (ba-bd)**2 + (ga-gd)**2 + (ra - rd)**2
								if max_dither_d < ab_error + ac_error + bc_error + ad_error: continue
								#if min_dither_d > ab_error + ac_error + bc_error + ad_error: continue
								bd_error = (bb-bd)**2 + (gb-gd)**2 + (rb - rd)**2
								if max_dither_d < ab_error + ac_error + bc_error + ad_error + bd_error: continue
								#if min_dither_d > ab_error + ac_error + bc_error + ad_error + bd_error: continue
								cd_error = (bc-bd)**2 + (gc-gd)**2 + (rc - rd)**2
								if max_dither_d < ab_error + ac_error + bc_error + ad_error + bd_error + cd_error: continue
								#if min_dither_d > ab_error + ac_error + bc_error + ad_error + bd_error + cd_error: continue
								checks += 1 
								error = (b_ - (ba+bb+bc+bd)/4)**2 + (g_ - (ga+gb+gc+gd)/4)**2 + (r_ - (ra+rb+rc+rd)/4)**2
								if error < low_e :
									#if error > max_dither_d or error < min_dither_d : continue 
									low_e = error 
									plan = [(ba,ga,ra),(bb,gb,rb),(bc,gc,rc),(bd,gd,rd)]
									print(f'{checks}:: {A} {B} {C} {D} : for {(b_,g_,r_)} got this plan {plan} with error {low_e}')
				print(f'{checks}:: {A} {B} {C} {D} : for {(b_,g_,r_)} got this plan {plan} with error {low_e} - min_dither_d {min_dither_d}  max_dither_d {max_dither_d}')


sys.exit()
#attempting verify for all 24 bit colors 
for b in range(256):
	print(f' verifying bgr for b = {b}')
	for g in range(256):
		for r in range(256):
			b = b_/255 
			g = g_/255 
			r = r_/255
			v = max(b,g,r)
			Cmin = min(b,g,r)
			delta = v - Cmin
			if v > 0 : 
				s = delta/v 
			else : s = 0
			if delta == 0 :
				h = 0
			elif v == r :
					h = int( 16/3*((b-g)/delta ) % 32 )
			elif v == g :
					h = int( 16/3*((b-r)/delta ) + 32/3)
			else :
					h = int( 16/3*((r-g)/delta ) + 64/3)
			s = int(23*s)
			v = int(15*v)
			missing = True
			for color,(h1,s1,v1) in h_l[h]:
				if s1 == s and v1 == v : 
					missing = False
					break 
			if missing :
				print(f'h_l[{h}] has no match for h {h} s {s} v {v} of {(b,g,r)}')

			missing = True
			for color,(h1,s1,v1) in s_l[s]:
				if v1 == v and h1 == h : 
					missing = False
					break 
			if missing :
				print(f's_l[{s}] has no match for h {h} s {s} v {v} of {(b,g,r)}')

			missing = True
			for color,(h1,s1,v1) in v_l[v]:
				if s1 == s and h1 == h : 
					missing = False
					break 
			if missing :
				print(f'v_l[{v}] has no match for h {h} s {s} v {v} of {(b,g,r)}')

"""
"""
initially missing 451 entries across h,s and v.. 
18*16*8 = 2304 .. so ~1/5 missing entries... 

removing the restriction to the palette...
now 19 saturations.. 2736 with 529 missing.. should be only unobtainables.. maybe can score against muddy things?
or the muddier things would be numerically closer together... as in less distance in rgb space.. so can cluster..

So adding them in shouldn't be _too_ bad ... or detect miss and go around it?
should test for arbitrary 24 bit.. 
calcumalating..
got 256 saturation.. expected.
256 values.. expected..
expanding quantizer for hues to 100x .. - 1024 values ... yeah... about that.. 
so quantize arbitrary h,s,v to ranges -
h to range(18) <- maybe to range 36.. ?
s to range(19)
v to range(8)

9bit palette naturally quantizes to 108 hues.. 18 variants between 6 main .. almost 1 ever 3.33 degress but seems disjoint.. ?
hmm.. ok .. 36 hues, 16 saturations, 8 values..

is setup to do classifier for all colors now to those..
so how many missing from all that? is 4608 combinations.. 
somehow only missing 844 .. mostly super saturated extreme hues.. easy peasy fix there.
cool can check that later.. hehe.


OK.. final thingy.. quantize to 32s. 

OK.. maybe not..
V quantizes to 16 values.. which is a trick anyway - those 16 values include the ones that fall in between.. 
which means the patches for v%2=1 are basically unions of the evens above and below - kinda sneaky like that.
saturation will be quantizes to 24..  just seems about right.
hue is quantized to 32.. should be plenty going on there.. 36 seemed about most natural and checking the patches
is not a lot - mostly it patches in some really low value / low saturation stuff ... which is fine for dithering
anyway.. 

so now strategy is a lot cleaner - for each pixel of the input, quantize h,s,v -> {32}{24}{16} .
then for step (h,s,v), add the set of colors at those points to the candidate list.. 
step %2=1 going up and step%2=0 going down ... so alternating.. 

then calc optimals, at each step preferencing dither plans that expand the palette the least. 
so start with color with largest score and going down.. 
each color of the palette "costs" an amount.. basically number of pixels in the image / num_colors .. 
so 100x100 image to 10 colors - each color would cost 1,000 ... 
key is the costs roll into each other.. 
"""
"""
palette_color_cost = int(num_pixels / num_colors)

for c,h,s,v,score in og : 
	total_allowed += score
	slots = int(total_allowed/palette_color_cost)
	low_e = 10000000
	plan = False
	if slots :
		#add more stuff to check. woot!
		potential_candidates = [i,c for i,c in enumerate(sorted([ p for p in (palette |  h_l[h]  | s_l[s] | v_l[s])]))]
	else :
		potential_candidates = pal_list
	used_slots = 0
	for i,c1 in potential_candidates:
		used_slots = 0
		if c1 not in palette : 
			if used_slots == slots : continue
			used_slots += 1
			for j,c2 in potential_candidates[i:]
				if c2 not in palette : 
					if used_slots == slots : continue
					used_slots += 1
				for k,c3 in potential_candidates[i:]
					if c3 not in palette : 
						if used_slots == slots : continue
						used_slots += 1
					for l,c4 in potential_candidates[i:]
						if c4 not in palette : 
							if used_slots == slots : continue
							used_slots += 1
							#calc dither...
					if c4 not in palette :
						used_slots -=1
				if c2 not in palette :
					used_slots -=1
	for color in plan :
		if color not in palette :
			total_allowed -= palette_color_cost

"""
