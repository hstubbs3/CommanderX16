#!/usr/bin/env python3
import sys
import numpy as np
import cv2 as cv
from time import sleep
from datetime import datetime 
from colormath.color_diff import delta_e_cie2000
from colormath.color_objects import LabColor, sRGBColor
from colormath.color_conversions import convert_color

def patch_asscalar(a):
    return a.item()

setattr(np, "asscalar", patch_asscalar)
cached_cie2000_diffs = {}
BGR_CIELAB_LOOKUP = {}
class Dither:
	def __init__(self,colorA,colorB,colorC):
		global cached_cie2000_diffs
		local_diffs = cached_cie2000_diffs
		global BGR_CIELAB_LOOKUP
		local_lookie = BGR_CIELAB_LOOKUP
		self.colors = (colorA,colorB,colorB, colorC)
		self.centroid = np.average(self.colors,axis=0)
		self.radius = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(self.centroid),tuple(self.colors[0]))
		#print(f'created a Dither : {self.centroid} - A: {colorA} B: {colorB} C: {colorC} ')

class DitherCluster:
	def __init__(self,d):
		self.dither = d
		self.children = []
		self.centroid = d.centroid
		self.radius = d.radius
		print(f'\t\t\t\t\tcreated a DitherCluster - {self.centroid} {self.dither.colors} {self.radius}')
	@property 
	def length(self):
		return len(self.children)
	def __iter__(self):
		return iter(self.children)
	def add(self,d):
		global cached_cie2000_diffs
		local_diffs = cached_cie2000_diffs
		global BGR_CIELAB_LOOKUP
		local_lookie = BGR_CIELAB_LOOKUP
		dd = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(self.centroid),tuple(d.centroid)) 
		print(f'\t\t\t\t\tDitherCluster : {self.centroid} {self.radius} - adding child : {d.centroid} with distance {dd}')
		self.children.append(d)
		if dd > self.radius :
			self.rebalance()
	def pop(self,i=-1):
		temp = self.children.pop(i)
		#print(f'\t\t\t\t\tDitherCluster : {self.centroid} {self.radius} - popped {i} : {temp.centroid} {temp.radius} {len(temp.children)} {temp.colors}')
		if len(self.children) == 0 :
			self.radius = self.dither.radius 
		else :
			self.rebalance()
		return temp
	def rebalance(self):
		global cached_cie2000_diffs
		local_diffs = cached_cie2000_diffs
		global BGR_CIELAB_LOOKUP
		local_lookie = BGR_CIELAB_LOOKUP
		best_candidate = 0
		best_radius = 1000000.0
		#print(f'starting rebalance for centroid {self.centroid} radius {self.radius} - num c = {len(self.children)}')
		for index,candidate in enumerate([self.dither] + self.children):
			r = 0.0 
			for c in [c for c in self.children + [self.dither] if c != candidate]:
				d = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(c.centroid),tuple(candidate.centroid))
				r+=d
			if r < best_radius:
				best_candidate = index 
				best_radius = r 
		if best_candidate :
			temp = self.children.pop(best_candidate-1)
			self.children.append(self.dither)
			self.dither = temp 
			self.radius = best_radius
			self.centroid = self.dither.centroid
		#print(f'did a rebalance...now centroid : {self.centroid} radius {self.radius} - num c = {len(self.children)}')

def do_clab_diff_with_lookies(local_lookie,local_diffs,colorA,colorB):

				minA = min(*colorA)
				minB = min(*colorB)
				if minB < minA :
					pair = (colorB,colorA)
				else :
					pair = (colorA,colorB)
				d = local_diffs.get(pair,-1)
				if d < 0 :
					c_labA = local_lookie.get(colorA,False)
					if not c_labA: 
						c_labA = convert_color(sRGBColor(int(colorA[2]),int(colorA[2]),int(colorA[0]),True),LabColor)
						local_lookie[colorA] = c_labA 
					c_labB = local_lookie.get(colorB,False)
					if not c_labB: 
						c_labB = convert_color(sRGBColor(int(colorB[2]),int(colorB[2]),int(colorB[0]),True),LabColor)
						local_lookie[colorB] = c_labB
					#print(f'c_labs : {type(c_labA)} {c_labA} {type(c_labB)} {c_labB}  ')
					d = delta_e_cie2000(c_labA,c_labB)
					local_diffs[pair] = d
				return d

def find_dither_clusters(img,num_colors=256,target_bits_channel=5,target_bits_red=None,target_bits_green=None,target_bits_blue=None):
	#print(str(datetime.now()))
	global cached_cie2000_diffs
	local_diffs = cached_cie2000_diffs
	global BGR_CIELAB_LOOKUP
	local_lookie = BGR_CIELAB_LOOKUP	

	if target_bits_red == None :
		target_bits_red = target_bits_channel
	if target_bits_green == None :
		target_bits_green = target_bits_channel
	if target_bits_blue == None :
		target_bits_blue = target_bits_channel
	modulus_red = 2**(8-target_bits_red)
	modulus_green = 2**(8-target_bits_green)
	modulus_blue = 2**(8-target_bits_blue)
	width,height,depth = img.shape
	BGR_to_dithers = {}
	#now we will diff all our colors together.. also note the conversions needed for palette back to BGR..?
	extant_dithers = set()
	dithers = []
	palette = set()
	for b,g,r in [(int(b),int(g),int(r)) for b,g,r in [p for row in img for p in row ]]:
		if not len(BGR_to_dithers) % (num_colors*num_colors) :
			print(f' so far palette of {len(palette)} for {len(BGR_to_dithers)} colors in image')
		p = (b,g,r)
		if p in local_lookie:
			continue
		else :
			BGR_to_dithers[p] = False
			local_lookie[p] = convert_color(sRGBColor(r,g,b,True),LabColor)
			bb,gg,rr = (min(255,max(0,int(b) - b%modulus_blue)),min(255,max(0,int(g) - g%modulus_green)),min(255,max(0,int(r) - r%modulus_red)) )
			color1 = (bb,gg,rr)
			local_lookie[color1] = convert_color(sRGBColor(rr,gg,bb,True),LabColor)
			palette.add(color1)
			color1 = (bb,gg,rr)
			for colorB in palette:
				for colorC in palette:
						if (color1,colorB,colorC) in extant_dithers :
								continue 
						else :
							dd = Dither(color1,colorB,colorC)
							dithers.append((dd.radius,dd))
							extant_dithers.add((color1,colorB,colorC))
			bb,gg,rr  = (min(255,max(0,int(b) - b%modulus_blue +modulus_blue)),min(255,max(0,int(g) - g%modulus_green +modulus_green)),min(255,max(0,int(r) - r%modulus_red +modulus_red)) )
			local_lookie[color1] = convert_color(sRGBColor(rr,gg,bb,True),LabColor)
			palette.add(color1)
			for colorB in palette:
				for colorC in palette:
						if (color1,colorB,colorC) in extant_dithers :
								continue 
						else :
							dd = Dither(color1,colorB,colorC)
							dithers.append((dd.radius,dd))
							extant_dithers.add((color1,colorB,colorC))

			continue
			for bb in [max(0,int(b) - b%modulus_blue),min(255,int(b) - b%modulus_blue + modulus_blue)]:
				for gg in [max(0,int(g) - g%modulus_green),min(255,int(g) + b%modulus_green + modulus_green)]:
					for rr in [max(0,int(r) - r%modulus_red),min(255,int(r) + r%modulus_red + modulus_red)]:
						color1 = (bb,gg,rr)
						if color1 in local_lookie: continue
						#print(color1)
						local_lookie[color1] = convert_color(sRGBColor(rr,gg,bb,True),LabColor)
						palette.add(color1)
	print(f'{datetime.now()}\tcalculated {target_bits_red}/{target_bits_green}/{target_bits_blue} bits starting palette of {len(palette)} and we have {len(BGR_to_dithers)} unique pixels original image')

	if len(palette) <= num_colors:
		print(f'oops... nothing to do...hehehe...{len(palett)} <= {num_colors}')
		sys.exit()
	dithers.sort()
	current_dither_used = 0
	max_dithers = len(dithers)
	threshold = 0.5
	double_threshold = 2.0*threshold
	rounds = 0
	while len(palette) > num_colors :
		rounds +=1
		print(f'{datetime.now()}\t{rounds} : {len(palette)} - {len(dither_clusters)} - threshold = {threshold}')
		while current_dither_used < max_dithers:
			if dithers[current_dither_used][0] < double_threshold :
				dither_clusters.append(dithers[current_dither_used][1])
				current_dither_used += 1
			else :
				break
		dc_refs = {k:v for k,v in enumerate(dither_clusters)}.items()
		for index,dc in dc_refs[:-1] :
			if not dc : continue 
			print(f'{datetime.now()}\tdoing {index} {dc.centroid}')
			print(f'{datetime.now()}\tdoing {dc.dither.centroid} - {dc.dither.colors} - radius {dc.radius} - {len(dc.children)} ')
			if dc.radius > threshold : continue
			for index2,dc2 in dc_refs[index+1:]:
				if not dc2 : continue
				d = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(dc2.centroid),tuple(dc.centroid))
				if d < dc.radius or d < dc2.radius :
					dc.children += dc2.children 
					dc.add([dc2.dither])
					dc2 = False 
					dc_refs[index2] = (index2,False)
		dither_clusters = []
		palette = set()
		for i,dc in dc_refs:
			if dc :
				dither_clusters.append(dc)
				palette.add(dc.dither.colors)
		print(f'{datetime.now()}\t Nomm nom a bunch! - {len(dither_clusters)} dithers using {len(palette)} colors..')
		threshold += 0.5
	sys.exit()
	print(f'{datetime.now()}\tproceeding to form initial clusterings... threshold = {threshold}')
	listpal = [(i,color) for i,color in enumerate(sorted(list(palette),key = lambda x: (x[0]*x[0]+x[1]*x[1]+x[2]*x[2],*x)))]
	for A,colorA in listpal:
		print(f'{datetime.now()}\tA {A} : {colorA} {len(dither_clusters)} {len(extant_dithers)}')
		low_distance = 1000000
		low_cluster = -1
		for di,dc in enumerate(dither_clusters):
			d = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(colorA),tuple(dc.centroid))
			if d < threshold:# or d < dc.radius:
				low_distance = d 
				low_cluster = di
				if d < threshold :
					break
		if low_cluster >= 0 :
			dither_clusters[low_cluster].add(Dither(colorA,colorA,colorA))
			extant_dithers.add((colorA,colorA,colorA))
		else :
			for B,colorB in listpal[A:]:
				d = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(colorA),tuple(colorB))
				if d < double_threshold :
					print(f'{datetime.now()}\tA {A} : {colorA}  	B {B} : {colorB} - {d}')
					for C, colorC in listpal[B:]:
						ditha = Dither(colorA,colorB,colorC)
						if ditha.radius > double_threshold :
							continue
						extant_dithers.add((colorA,colorB,colorC))
						low_d= 1000000 
						low_cluster = -1
						for di,dc in enumerate(dither_clusters):
							if dc.radius > double_threshold :
								continue
							d = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(ditha.centroid),tuple(dc.centroid))
							if d < double_threshold :#or d < dc.radius:
								low_d = d 
								low_cluster = di 
								if d < threshold :
									break
						if low_cluster >= 0:
							dither_clusters[low_cluster].add(ditha)
							#if dither_clusters[low_cluster].radius > double_threshold :
							#	while dither_clusters[low_cluster].children :
							#		dither_clusters.append(DitherCluster(dither_clusters[low_cluster].pop()))
							extant_dithers.add((colorA,colorB,colorC))
						else :
							dither_clusters.append(DitherCluster(ditha))
	used_colors = {}
	for di,dc in enumerate(dither_clusters):
		print(f'{di} - {dc.dither.centroid} - {dc.dither.colors} - radius {dc.radius} - {len(dc.children)} ')
		for color in dc.dither.colors :
			used_colors[color] = 1 + used_colors.get(color,0)

		for ci,c in enumerate(dc) : 
			print(f'\t\t\t{ci} {c.centroid} {c.colors} - {c.radius}')
	palette = used_colors
	print(f'{datetime.now()}\tround : 0 ! {len(palette)} > {num_colors} : with {len(dither_clusters)} dither clusters - needs actually {len(used_colors)} colors')
	for i,*color in enumerate(used_colors.items()):
		print(f'{i} {color}')


	sys.exit()
	"""
	rounds = 0 
	while len(palette) > num_colors:
		rounds +=1 
		print(f'{datetime.now()}\tround : {rounds} ! {len(palette)} > {num_colors} : using {len(dither_clusters)}')
		listpal = [(i,color) for i,color in enumerate(sorted(list(palette),key = lambda x: ((128-x[0])**2 + (128-x[1])**2 +(128-x[2])**2,min(*x),*x)))]

			for B,colorB in listpal[A+1:]:
				#print(f'\t\t\tB : {B} - {colorB}')
				if d < low_distance:
						low_distance = d 
						low_B = colorB
						low_Bi = B
						if d < threshold :
							break
					if d > 2*low_distance:
						break
				else :
					continue
			if low_B:
				minA = min(*colorA)
				minB = min(*low_B)
				if minB < minA :
					pair = (low_B,colorA)
				else :
					pair = (colorA,low_B)
				#print(f'{datetime.now()}\tA : {A} B : {low_Bi} - {colorA} - {pair} - {low_distance}')
			#else :
				#print(f'{datetime.now()}\tA : {A} {colorA} - low distance {low_distance}')
			#local_diffs[pair] = low_distance
			#pair_diff_list.append((low_distance,pair[0],pair[1]))
		#print(str(datetime.now()))
		pair_diff_list.sort()
		to_remove = len(palette) - max_colors_before_dither
		#threshold = pair_diff_list[0][0]
		if to_remove > 0 :
			print(f'{datetime.now()}\tthreshold set to {threshold} palette of {len(palette)}')
			print(f'{datetime.now()}\t only got {len(pair_diff_list)} pair results to sift through... one moment..')
			for i,d,colorA,colorB in [(index,data[0],data[1],data[2]) for index,data in enumerate(pair_diff_list)]:
				if d > threshold : break
				if colorA in palette and colorB in palette :
					b,g,r = colorA 
					b2,g2,r2 = colorB 
					bb = int((b+b2)/2)
					gg = int((g+g2)/2)
					rr = int((r+r2)/2)
					newColor = (bb - bb % modulus_blue, gg - gg % modulus_green, rr - rr % modulus_red)
					palette.remove(colorA)
					palette.remove(colorB)
					palette.add(newColor)
					#for j,d2,colorC,colorD in [(index,data[0],data[1],data[2]) for index,data in enumerate(pair_diff_list)]:
					#	if i == j : continue 
					#	if d2 > threshold*2 -d : break
					#	if colorB == colorC and colorC in palette :
					#		palette.remove(colorB)
					#		to_remove -= 1
					#		print(f'{datetime.now()}\t{i}\t{d}\t{colorA}\t{colorB}\t{colorC} - only {to_remove} left to go...')
					#		if to_remove < 1:
					#			break
			#threshold = pair_diff_list[min(i+1,len(pair_diff_list)-1)][0]
		threshold += 0.1
		print(f'{datetime.now()}\tthreshold set to {threshold} palette of {len(palette)}')
		if threshold >= 10 :
			break

	print(f'{datetime.now()}\tenriching with possible dither endpoints')
	listpal = [(i,*local_lookie[color].get_value_tuple(),*color) for i,color in enumerate(list(palette))]
	double_threshold = 2*threshold
	for A,la,aa,ba,BA,GA,RA in listpal:
		print(f'{datetime.now()}\t\tA: {A} - ( {BA} {GA} {RA} )')
		palette.add((min(255,max(0,BA-modulus_blue)),min(255,max(0,GA-modulus_green)),min(255,max(0,RA-modulus_red))))
		palette.add((min(255,max(0,BA+modulus_blue)),min(255,max(0,GA+modulus_green)),min(255,max(0,+modulus_red))))
	print(f'{datetime.now()}\tready for constructing / initial clustering of dithers -palette of {len(palette)}')

				palette.add((b,g,r))
	dithers = set()
	listpal = [(i,color) for i,color in enumerate(palette) ]
	for i,colA in listpal:
		print(f'{datetime.now()}\t{i} {colA} - constructing dithers')
		for j,colB in listpal:
			for k,colC in listpal[j:]:
				centroid = np.average([colA,colB,colB,colC],axis=0)
				bad = False
				for dithy in dithers :
					d = do_clab_diff_with_lookies(local_lookie,local_diffs,tuple(centroid),dithy[0])
					if d < threshold :
						bad = True
						#print(f'{datetime.now()}\t{len(dithers)} : {colA} | {colB} | {colC} too similar to {dithy[1]} | {dithy[2]} | {dithy[3]} - {d}')
						break
				if bad : continue
				dithers.add((tuple(centroid),colA,colB,colC))

	print(f'{datetime.now()}\tdithers : {len(dithers)}  palette : {len(palette)}')
	"""
	sys.exit()
	"""
				dither = Dither
				minA = min(*colorA)
				for dc in ditherClusters :
					minB = min(*colorB)
				if minB < minA :
					pair = (colorB,colorA)
				else :
					pair = (colorA,colorB)
				d = local_diffs.get(pair,-1)
				if d < 0 :
					c_labA = local_lookie.get(colorA,False)
					if not c_labA: 
						c_labA = convert_color(sRGBColor(int(colorA[2]),int(colorA[2]),int(colorA[0]),True),LabColor)
						local_lookie[colorA] = c_labA 
					c_labB = local_lookie.get(colorB,False)
					if not c_labB: 
						c_labB = convert_color(sRGBColor(int(colorB[2]),int(colorB[2]),int(colorB[0]),True),LabColor)
						local_lookie[colorB] = c_labB
					#print(f'c_labs : {type(c_labA)} {c_labA} {type(c_labB)} {c_labB}  ')
					d = delta_e_cie2000(c_labA,c_labB)
					local_diffs[pair] = d
					pair_diff_list.append((d,pair[0],pair[1]))
					diff = local_diffs()
				#print(f'{datetime.now()}\t\t\t{i} : {colorA} | {j} : {colorB} | {k} :{colorC}')
		variants = []
				for color2 in palette :
					b2,g2,r2 = color2
					for color3 in palette :
						if color2 == color3 :
								continue
						b3,g3,r3 = color3
						variants += [ [color1,color2,color2,color3],[color1,color3,color3,color2],[color2,color1,color1,color3] ]
	print(f'end of {y} : {len(variants)}')
	 and {len(variants)} dithers...')
	sys.exit()
	return palette,dithers
	"""

def do_dithers(img,dithers):
	img_out = np.zeros((len(img),len(img[0]),3),np.uint8)
	for y,row in enumerate(img):
		y_mod2 = 2*(y % 2)
		for x,pixel in enumerate(row):
			b,g,r = pixel 
			b = int(b)
			g = int(g)
			r = int(r)
			p = (b,g,r)
			img_out[y][x] = dithers[p][ymod2 + (x%2)]
	return img_out

img = cv.imread(sys.argv[1],cv.IMREAD_ANYCOLOR)
colors,dithers=find_dither_clusters(img,16,3)
"""
print(f'got a palette of {len(colors)} colors')
cv.imshow('HFS III',do_dithers(img,dithers))
print('fin')
cv.waitKey(0)
cv.destroyAllWindows() # destroy all windows
"""
