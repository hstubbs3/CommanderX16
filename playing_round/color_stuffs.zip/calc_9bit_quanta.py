#!/usr/bin/env python3
import numpy as np
import cv2 as cv


img = np.zeros((720,1280,3),np.uint8)
cv.imshow('window',img)
cv.moveWindow('window',600,-1080)

hue_list = []
sat_list = []
val_list = []
for x in range(1280):
	v = min(255,int(320 - x/5))
	for y in range(720):
		img[y][x]=(v,v,v)
for b_ in range(0,255,32):
	for g_ in range(0,255,32):
		for r_ in range(0,255,32):
			b = b_/255 
			g = g_/255 
			r = r_/255
			v = max(b,g,r)
			Cmin = min(b,g,r)
			delta = v - Cmin
			if v > 0 : s = delta/v 
			else : s = 0
			if delta == 0 :
				h = 0 
			elif v == r :
				h = 60*( ((g-b)/delta) % 6 ) 
			elif v == g :
				h = 60*( ((b-r)/delta) + 2 )
			else :
				h = 60*( ((r-g)/delta) + 4 )
			print(f'bgr = {b_,g_,r_} : h = {int(h)} s = {int(255*s)} v = {int(255*v)}')
			c = (b_,g_,r_)
			hue_list.append((int(h),c))
			sat_list.append((int(255*s),c))
			val_list.append((int(255*v),c))
			y = int(2*h)
			x = int(v*1275)+int(31*s)
			for yd in [0,1,2,3,4,5,6,7]:
				for xd in [0,1,2]:
					img[y+yd][x+xd]=(b_,g_,r_)
			cv.imshow('window',img)
			cv.waitKey(1)
hue_list.sort()
print(f'hue list : {hue_list}')
sat_list.sort()
print(f'sat list : {sat_list}')
val_list.sort()
print(f'val list : {val_list}')

cv.waitKey(0)
cv.destroyAllWindows() # destroy all windows

"""
OK.. so V is only 8 possible values - 	0 	32 	64 	96 	128 	160 	192 	224 
H is a little weirder - about 14 between red and green.. so about 42 but the number varies based on value/saturation..
saturation ... up by v=224,we have ~7 levels of saturation depending on hue.. 

actually v,s is like 

	V	000 	032 	064 	096 	128 	160 	192 	224
S 		1 		2  		3 		4 		5 		5 		 7 		8 		= 	35 levels total...

V < 128 may as well be greys? 

Suggests a reduced palette.. 				H 		S 		V
v=32 : (32,32,32) as "black" 	1  			0 		0 		1
v=64 : 	64,64,64 	grey 		7 	8 		0 		0 		2
		0,0,64 		red 					0 		7 		2
		0,64,64 	yellow 					2 		7 		2
		0,64,0 		green 					4 		7 		2
		64,64,0 	cyan	 				6 		7 		2
		64,0,0 		blue 					8 		7 		2
		64,0,64 	purple 					10 		7 		2
v = 96 	96,96,96 	grey 		7 	15 		0 		0 		3
		0,0,96 		red 					0 		7 		3
		0,96,96 	yellow 					2 		7 		3
		0,96,0 		green 					4 		7 		3
		96,96,0 	cyan 					6 		7 		3
		96,0,0 		blue 					8 		7 		3
		96,0,96 	purple 					10 		7 		3
v = 128 : grey + 12 tints -	13 		28 		
	(128,128,128)  							0 		0 		4
	(0,0,128)  								0 		7 		4
	(0,64,128) 								1 		
	(0,128,128)  							2
	(0,128,64) 								3
	(0,128,0)  								4
	(64,128,0) 								5
	(128,128,0) 							6
	(128,64,0) 								7
	(128,0,0) 								8
	(128,0,64)								9
	(128,0,128)								10
	(64,0,128)								11
v = 160 : 					27 	55 <- 	1 * 4 * 2 - 	160,(0,96,160),(0,96,160) ... otay that's 27...
v = 192 : grey + 24 tints  	36 	91 						192,(0,64,128,192),(0,96,192) 	36
v = 224 : white + 48 tints 	36 	127 					224,(0,96,160,224),(0,128,224) 	36

That's mental.. and precalculatable... 
otay..

"""