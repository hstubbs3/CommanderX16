#!/usr/bin/env python3
import sys
import numpy as np
import cv2 as cv
from time import sleep


def make_hsv_from_rgb(r_,g_,b_):
	r = r_/255
	g = g_/255
	b = b_/255
	Cmax = max(r,g,b)
	Cmin = min(r,g,b)
	delta = Cmax - Cmin
	v = Cmax 

	if Cmax > 0 : s = delta/Cmax
	else : s = 0

	if s == 0 :
		h = 0
	elif s < 0.5:
		h = 60*4*s 
		h -= h%6
		if Cmax == g :
			if Cmin == b : h += 0
			else : h += 1 
		elif Cmax == b :
			if Cmin == r : h += 2
			else : h +=3
		else :
			if Cmin == g : h += 4
			else : h +=5
	elif Cmax == r :
		h = 60*( ((g-b)/delta) + 7) 
	elif Cmax == g :
		h = 60*( ((b-r)/delta) + 3 )
	else :
		h = 60*( ((r-g)/delta) + 5 )
	return h,s,v 

#img_value = np.zeros((512,720,3),np.uint8)
#img_saturation = np.zeros((512,720,3),np.uint8)
img_val_saturation = np.zeros((1024,1440,3),np.uint8)
#cv.imshow('value',img_value)
#cv.imshow('saturation',img_saturation)
cv.imshow('combined',img_val_saturation)
#cv.moveWindow('value',0,0)
#cv.moveWindow('saturation',720,0)
cv.moveWindow('combined',100,0)
for b in range(511,-1,-1):
	for g in range(0,512,1):
		for r in range(0,512,1):
			h,s,v = make_hsv_from_rgb(r/2,g/2,b/2 )
			#x = int(1439 * s) - int(1439*s)%90 + int(h/4)
			y = min(1023,4*max(b,g,r))
			#y = y - (y % 64) + (s * 63)
			x = min(3*h,1439)
			img_val_saturation[int(y) ][int(x)] = (b,g,r)
	print(b,g,r)
#	cv.imshow('value',img_value)
#	cv.imshow('saturation',img_saturation)
	cv.imshow('combined',img_val_saturation)
	cv.waitKey(1)

cv.waitKey(0)
cv.destroyAllWindows()