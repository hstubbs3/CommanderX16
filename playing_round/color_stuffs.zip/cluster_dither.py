#!/usr/bin/env python3
import sys
import numpy as np
import cv2 as cv
from time import sleep
from datetime import datetime 
from colormath.color_diff import delta_e_cie2000
from colormath.color_objects import LabColor, sRGBColor
from colormath.color_conversions import convert_color

def patch_asscalar(a):
    return a.item()

setattr(np, "asscalar", patch_asscalar)

"""
Process in the abstract - 
we only have ~16 slots.. so we want to identify ~16 regions in the ~4d space ..
so need to find place to split in half... light/dark r/R g/G b/B
[bW][rR][gG][bB]
naturally is then like...correlations between those dimensions to make little hyper-cube babies...

"""
def do_cluster_dither_to_3bit_channels(img,num_colors=16):
    height = len(img)
    width = len(img[0])

    og_colors = {}
    dither_to_og = {}
    total_pixels = height * width
    split_at = int(total_pixels/num_colors)
    for y,row in enumerate(img):
        print(f'{datetime.now()}\tgetting OG colors - row {y} - {len(og_colors)} og_colors')
        for x,converted,pixel in [(x,(int(c+16) - int(c+16)%32 for c in pixel),(int(c) for c in pixel)) for x,pixel in enumerate(row)]:
            og_colors[pixel] = [1 + og_colors.get(pixel,0),converted]
            if converted in dither_to_og:
                dither_to_og[converted][1].add(pixel)
            else :
                dither_to_og[converted] = [(converted,converted,converted),set().add(pixel)]
        break
    print(f'{datetime.now()}\twe got {len(og_colors)} original colors converted to {len(dither_to_og)}')
    if len(dither_to_og) > num_colors :
        splits = []
        pal_list = sorted([(k,v) for k,v in dither_to_og.items()],key = lambda x: max(*x[0]))
        index = len(dither_to_og)
        remainder = 0
        for split_it in range(0,total_pixels,split_at):
            remainder += split_at
            temp_split = []
            while index > 0 :
                index -= 1 
                c,s = pal_list[index]
                for og in s :
                    remainder -= og_colors[og]
                temp_split.append(t)
                if remainder <= 0 :
                    break
            splits.append(temp_split)
        while len(splits) > num_colors :
            t = splits.pop()
            splits[-1]+= t
        print(f'{datetime.now()}\tinitial split into contrasting spaces...')
        for split in splits :
            print(f'{len(split)} :{split[0]} - {split[-1]}')

img = cv.imread(sys.argv[1],cv.IMREAD_ANYCOLOR)
colors,dithers = do_cluster_dither_to_3bit_channels(img)

