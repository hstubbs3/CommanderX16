#! /usr/bin/env python3
def make_vhs_from_rgb(r,g,b):
	Cmax = max(r,g,b)
	Cmin = min(r,g,b)
	delta = Cmax - Cmin

	if delta == 0:
		h = 0
	elif Cmax == r :
		h = int(60*( ((g-b)/delta) % 6 ))
	elif Cmax == g :
		h = int(60*( ((b-r)/delta) + 2 ))
	else :
		h = int(60*( ((r-g)/delta) + 4 ))

	if Cmax > 0 : s = int(255.0*delta/Cmax)
	else : s = 0

	v = Cmax 

	return v,h,s 


def hue_difference(h_a,h_b):
	max = max(h_a,h_b)
	min = min(h_a,h_b)
	return min(max - min, min + 360 - max )


def diff_vhs(hsv_a, hsv_b):
	va, ha,sa = hsv_a
	vb, hb,sb = hsv_b
	return max(va - vb, vb - vb),hue_difference(ha,hb), max(sa - sb, sb - sa ) 

def make_rgb_from_vhs(v,h,s):
	if s == 0:
		return v,v,v
	else:
		delta = int(s/255.0 * v)
		Cmin = v - delta
		if h<60 : #Cmax==R, b is min
			return v,int(delta * (h/60.0) + Cmin),Cmin
		elif h<120: #Cmax==G,b is min
			return int(delta * ((h-60)/60.0) + Cmin),v,Cmin 
		elif h<180: #Cmax==G, R is min
			return Cmin,v, int(delta * ((h-120)/60.0) + Cmin)
		elif h<240: #CMax==B,r is min
			return Cmin, int(delta * ((h-180)/60.0) + Cmin), v 
		elif h<300: #Cmax==B, g is min
			return int(delta * ((h-240)/60.0) + Cmin), Cmin, v
		else: #Cmax==R, g is min
			return v, Cmin, int(delta * ((h-300)/60.0) + Cmin)


print('testing making rgb fom vhs 255,359,255')
for (v,h,s) in [(0,0,0),(255,30,32),(128,240,64),(128,240,128),(128,240,224)]:
	print(f'v:{v} h:{h} s:{s} = rgb {make_rgb_from_vhs(v,h,s)}')

print('ultimate 16 color palette...')
ulimate_pal_vhs = [ 	(0,0,0), 		#0 	black
						(255,0,0),		#1 	white
						(128,0,0), 		#2 	middle grey
						(96,0,128), 	#3 	low red
						(255,0,255), 	#4 	high red
						(96,60,128), 	#5 	yellow
						(96,120,128), 	#7 	low green
						(96,180,128), 	#9 	low cyan
						(96,240,128),	#B 	low blue
						(96,300,128), 	#D 	low purple
						